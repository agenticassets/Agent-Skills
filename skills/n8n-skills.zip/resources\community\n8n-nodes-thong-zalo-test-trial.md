# n8n-nodes-thong-zalo-test-trial

## Basic Information

- Package: `n8n-nodes-thong-zalo-test-trial`
- Category: 🔧 Utilities & Tools
- Version: 0.1.182
- Maintainer: vanthong0404
- npm: [View Package](https://www.npmjs.com/package/n8n-nodes-thong-zalo-test-trial)

## Description

Các node hỗ trợ Zalo cho n8n

## Installation

```
n8n-nodes-thong-zalo-test-trial
```

## Node Details

> Node details unavailable: Installation failed

---

[← Back to Community Nodes Index](README.md)
