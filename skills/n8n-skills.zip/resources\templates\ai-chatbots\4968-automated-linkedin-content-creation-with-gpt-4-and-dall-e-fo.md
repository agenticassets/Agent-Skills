# Automated LinkedIn Content Creation with GPT-4 and DALL-E for Scheduled Posts
> **Category**: AI & Chatbots
> **Views**: 20,561
> **Created**: 6/16/2025
## Description
How it works
Automatically generates trending LinkedIn content topics using AI
Researches current industry angles and hooks  
Writes posts in your authentic voice using OpenAI
Creates professional images with DALL-E
Posts everything on schedule without manual intervention

Set up steps
Connect OpenAI API for content generation and image creation
Link LinkedIn API for automated posting
Configure scheduling triggers (daily/weekly posting)
Customize prompts to match your writing style and industry
Set up content approval workflows (optional)

Results you can expect
400% increase in profile views within 3 weeks
Generate 120+ posts per month vs manual 12 posts
Free up 15+ hours weekly for revenue-generating activities
Consistent posting schedule that builds audience engagement
Professional content that converts followers to clients

Time to set up: 30-45 minutes
Technical level: Beginner to intermediate
APIs required: OpenAI, LinkedIn API
Cost: OpenAI usage fees only (approximately $5-15/month)

This workflow transforms LinkedIn content creation from a time-consuming daily task into a fully automated system that works while you sleep. Perfect for entrepreneurs, marketers, and content creators who want consistent LinkedIn presence without the manual effort.
## Workflow Structure
# Automated LinkedIn Content Creation with GPT-4 and DALL-E for Scheduled Posts

## Basic Information

- Node count: 13
- Connection count: 13

## Key Nodes

### Triggers
- Schedule Trigger (`n8n-nodes-base.scheduleTrigger`)

### AI Nodes
- Content topic generator2 (`@n8n/n8n-nodes-langchain.agent`)
- OpenAI Chat Model (`@n8n/n8n-nodes-langchain.lmChatOpenAi`)
- Structured Output Parser (`@n8n/n8n-nodes-langchain.outputParserStructured`)
- Content creator (`@n8n/n8n-nodes-langchain.chainLlm`)
- OpenAI Chat Model1 (`@n8n/n8n-nodes-langchain.lmChatOpenAi`)
- Structured Output Parser1 (`@n8n/n8n-nodes-langchain.outputParserStructured`)
- OpenAI (`@n8n/n8n-nodes-langchain.openAi`)
- Hashtag generator /SEO (`@n8n/n8n-nodes-langchain.agent`)
- OpenAI Chat Model2 (`@n8n/n8n-nodes-langchain.lmChatOpenAi`)
- Structured Output Parser2 (`@n8n/n8n-nodes-langchain.outputParserStructured`)

## All Nodes

| Node Name | Type | Category |
|-----------|------|----------|
| Schedule Trigger | `n8n-nodes-base.scheduleTrigger` | Trigger |
| Content topic generator2 | `@n8n/n8n-nodes-langchain.agent` | AI |
| OpenAI Chat Model | `@n8n/n8n-nodes-langchain.lmChatOpenAi` | AI |
| Structured Output Parser | `@n8n/n8n-nodes-langchain.outputParserStructured` | AI |
| Content creator | `@n8n/n8n-nodes-langchain.chainLlm` | AI |
| OpenAI Chat Model1 | `@n8n/n8n-nodes-langchain.lmChatOpenAi` | AI |
| Structured Output Parser1 | `@n8n/n8n-nodes-langchain.outputParserStructured` | AI |
| OpenAI | `@n8n/n8n-nodes-langchain.openAi` | AI |
| Hashtag generator /SEO | `@n8n/n8n-nodes-langchain.agent` | AI |
| OpenAI Chat Model2 | `@n8n/n8n-nodes-langchain.lmChatOpenAi` | AI |
| Structured Output Parser2 | `@n8n/n8n-nodes-langchain.outputParserStructured` | AI |
| Merge | `n8n-nodes-base.merge` | Transform |
| LinkedIn | `n8n-nodes-base.linkedIn` | Other |

## Connections

```
Merge --[main]--> LinkedIn
OpenAI --[main]--> Merge
Content creator --[main]--> OpenAI
Content creator --[main]--> Hashtag generator /SEO
Schedule Trigger --[main]--> Content topic generator2
OpenAI Chat Model --[ai_languageModel]--> Content topic generator2
OpenAI Chat Model1 --[ai_languageModel]--> Content creator
OpenAI Chat Model2 --[ai_languageModel]--> Hashtag generator /SEO
Hashtag generator /SEO --[main]--> Merge
Content topic generator2 --[main]--> Content creator
Structured Output Parser --[ai_outputParser]--> Content topic generator2
Structured Output Parser1 --[ai_outputParser]--> Content creator
Structured Output Parser2 --[ai_outputParser]--> Hashtag generator /SEO
```

## Workflow Summary

This workflow is triggered by Schedule Trigger, uses Content topic generator2, OpenAI Chat Model, Structured Output Parser, Content creator, OpenAI Chat Model1, Structured Output Parser1, OpenAI, Hashtag generator /SEO, OpenAI Chat Model2, Structured Output Parser2 for AI processing, goes through 1 transformation step(s).
## Author Information
- **Name**: Samuel Kimutai
- **Username**: @agenticvibe
## Related Links
- [View this template on n8n.io](https://n8n.io/workflows/4968)
## Complete Workflow JSON
<details>
<summary>Click to expand Workflow JSON</summary>
```json
{
  "name": "Automated LinkedIn Content Creation with GPT-4 and DALL-E for Scheduled Posts",
  "nodes": [
    {
      "id": "7f5f9934-7ab8-43e9-a4cb-1583740a2e36",
      "name": "Schedule Trigger",
      "type": "n8n-nodes-base.scheduleTrigger",
      "position": [
        -840,
        640
      ],
      "parameters": {
        "rule": {
          "interval": [
            {
              "field": "hours",
              "hoursInterval": 6
            }
          ]
        }
      },
      "typeVersion": 1.2
    },
    {
      "id": "928e2771-ec9f-48ff-b34e-9c3ab9c4a828",
      "name": "Content topic generator2",
      "type": "@n8n/n8n-nodes-langchain.agent",
      "position": [
        -500,
        640
      ],
      "parameters": {
        "text": "You are a Content Researcher Assistant at Agentic Vibe, an AI-first automation agency helping solopreneurs, creators, and digital-first founders grow their online presence — especially on LinkedIn — through scalable, hands-free content systems.\n\nYour task is to generate high-value content topics that align with our brand pillars and resonate deeply with our audience. These topics will later be expanded into posts by another agent.\n\n🔍 What to Focus On:\nGenerate content topics (not full content) based on these strategic themes:\n\nAI for Content Creation & Workflow Automation\n\nLinkedIn Automation Tools, Tactics & Growth Strategies\n\nSolopreneur Productivity Hacks Using AI & Automation\n\nSystems Thinking for Scaling Personal Brands\n\nThe Future of Work, Creators, and Automated Influence\n\nNo-Code Tools for Content & Lead Gen Automation\n\n✅ Your Output Per Topic:\nFor each idea, generate the following:\n\nTopic Title or Core Idea (1 line)\n\nShort Rationale (1–2 sentences on why this topic matters)\n\nSuggested Angle or Hook (1 LinkedIn-style framing or contrarian take)\n\n💡 Style Guide:\nKeep ideas insightful, actionable, and future-minded\n\nFavor founder-style energy: confident, sharp, and slightly contrarian when it adds value\n\nAvoid hype or jargon — focus on clarity, systemized insight, and utility",
        "options": {},
        "promptType": "define",
        "hasOutputParser": true
      },
      "typeVersion": 2
    },
    {
      "id": "10577345-0f96-42bf-a5db-7f9f205f7359",
      "name": "OpenAI Chat Model",
      "type": "@n8n/n8n-nodes-langchain.lmChatOpenAi",
      "position": [
        -500,
        880
      ],
      "parameters": {
        "model": {
          "__rl": true,
          "mode": "list",
          "value": "gpt-4o-mini"
        },
        "options": {}
      },
      "credentials": {
        "openAiApi": {
          "id": "YOUR_OPENAI_CREDENTIAL_ID",
          "name": "OpenAI API"
        }
      },
      "typeVersion": 1.2
    },
    {
      "id": "c7094a20-a96a-4db8-9ee4-95f86de800ac",
      "name": "Structured Output Parser",
      "type": "@n8n/n8n-nodes-langchain.outputParserStructured",
      "position": [
        -320,
        860
      ],
      "parameters": {
        "jsonSchemaExample": "[{\n \"title\": \"AI as Your First Content Hire: Why Founders Shouldn't Wait to Outsource Creation\",\n            \"rationale\": \"Most solopreneurs delay content scaling because they think hiring a ghostwriter is the next step — but AI can handle 80% with proper systems. This shifts content from a creative bottleneck to a scalable growth lever.\",\n            \"hook\": \"Ghostwriters are outdated. Train GPT once, and it ships LinkedIn gold in your voice daily. Welcome to hands-free thought leadership.\"\n          }]"
      },
      "typeVersion": 1.2
    },
    {
      "id": "84b30f40-e7fa-4c46-9a82-39bbd2becfe0",
      "name": "Content creator",
      "type": "@n8n/n8n-nodes-langchain.chainLlm",
      "position": [
        -80,
        640
      ],
      "parameters": {
        "text": "=You are a linkedin content creator and copywriter. Given the title {{ $json.output[0].title }}, the rationale {{ $json.output[0].rationale }}, suggested hook. Generate text content for a linkedin post. Also describe a suitable image for the post.",
        "batching": {},
        "promptType": "define",
        "hasOutputParser": true
      },
      "typeVersion": 1.7
    },
    {
      "id": "6fdea8df-7cb4-4418-8dab-e5faa9e76b6b",
      "name": "OpenAI Chat Model1",
      "type": "@n8n/n8n-nodes-langchain.lmChatOpenAi",
      "position": [
        -80,
        820
      ],
      "parameters": {
        "model": {
          "__rl": true,
          "mode": "list",
          "value": "gpt-4o-mini"
        },
        "options": {}
      },
      "credentials": {
        "openAiApi": {
          "id": "YOUR_OPENAI_CREDENTIAL_ID",
          "name": "OpenAI API"
        }
      },
      "typeVersion": 1.2
    },
    {
      "id": "cc1e5e3c-31de-4d1b-948b-89165fbc9769",
      "name": "Structured Output Parser1",
      "type": "@n8n/n8n-nodes-langchain.outputParserStructured",
      "position": [
        80,
        820
      ],
      "parameters": {
        "jsonSchemaExample": "{\n  \"post title\": \"Exciting New Feature Launch 🚀\",\n  \"post content\": \"After months of collaboration, testing, and fine-tuning, we're thrilled to introduce our latest product feature: Smart Insights. It helps users uncover meaningful patterns in their data with just a few clicks. This wouldn't have been possible without our incredible team and supportive community. We're excited for what's next — and we'd love your feedback!\",\n  \"image description\": \"A laptop screen showcasing the new Smart Insights dashboard with colorful charts and graphs, surrounded by a team clapping in the background.\"\n}"
      },
      "typeVersion": 1.2
    },
    {
      "id": "2ae88f2a-031c-41c3-bbb9-f1555d94863a",
      "name": "OpenAI",
      "type": "@n8n/n8n-nodes-langchain.openAi",
      "position": [
        420,
        460
      ],
      "parameters": {
        "prompt": "=Generate an image for a linkedin post this is the description: {{ $json.output['image description'] }} .The images should be realistic for linkedin.",
        "options": {},
        "resource": "image"
      },
      "credentials": {
        "openAiApi": {
          "id": "YOUR_OPENAI_CREDENTIAL_ID",
          "name": "OpenAI API"
        }
      },
      "typeVersion": 1.8
    },
    {
      "id": "f3901b98-cfe4-4d48-9e35-59161cbcfdd9",
      "name": "Hashtag generator /SEO",
      "type": "@n8n/n8n-nodes-langchain.agent",
      "position": [
        420,
        900
      ],
      "parameters": {
        "text": "=You are an SEO specialist for LinkedIn. Your task is to generate highly relevant and effective hashtags for the following post. Consider the post's content, target audience, and current LinkedIn trends to maximize visibility and engagement.\n\n<post_title>{{ $json.output['post title'] }}</post_title>\n<post_content>{{ $json.output['post content'] }}</post_content>\n\nPlease generate:\n1. **3-5 broad, high-volume hashtags** (e.g., #AI, #Marketing, #Business)\n2. **3-5 niche-specific hashtags** that are directly relevant to the post's core topic (e.g., #SocialMediaAutomation, #ContentCreationAI, #LinkedInMarketingTips)\n3. **1-2 trending/topical hashtags** if applicable (e.g., #FutureOfWork, #DigitalTransformation)\n\nPresent them as a comma-separated list.",
        "options": {},
        "promptType": "define",
        "hasOutputParser": true
      },
      "typeVersion": 2
    },
    {
      "id": "f3d91646-6d7b-4270-85bc-0e4684bbd0d0",
      "name": "OpenAI Chat Model2",
      "type": "@n8n/n8n-nodes-langchain.lmChatOpenAi",
      "position": [
        420,
        1100
      ],
      "parameters": {
        "model": {
          "__rl": true,
          "mode": "list",
          "value": "gpt-4o-mini"
        },
        "options": {}
      },
      "credentials": {
        "openAiApi": {
          "id": "YOUR_OPENAI_CREDENTIAL_ID",
          "name": "OpenAI API"
        }
      },
      "typeVersion": 1.2
    },
    {
      "id": "692b1c2e-bdc7-474e-859e-204970f512a6",
      "name": "Structured Output Parser2",
      "type": "@n8n/n8n-nodes-langchain.outputParserStructured",
      "position": [
        600,
        1100
      ],
      "parameters": {
        "jsonSchemaExample": "{\n  \"post title\": \"Exciting New Feature Launch 🚀\",\n  \"post content\": \"After months of collaboration, testing, and fine-tuning, we're thrilled to introduce our latest product feature: Smart Insights. It helps users uncover meaningful patterns in their data with just a few clicks. This wouldn't have been possible without our incredible team and supportive community. We're excited for what's next — and we'd love your feedback!\",\n  \"image description\": \"A laptop screen showcasing the new Smart Insights dashboard with colorful charts and graphs, surrounded by a team clapping in the background.\",\n\"Hashtags\":[\"#AI\",\"#Automation\"]\n}"
      },
      "typeVersion": 1.2
    },
    {
      "id": "f667d091-72aa-4bea-9648-4563a75265ff",
      "name": "Merge",
      "type": "n8n-nodes-base.merge",
      "position": [
        780,
        640
      ],
      "parameters": {},
      "typeVersion": 3.2
    },
    {
      "id": "7c3a37b7-3227-43a7-86fb-c39e885570bf",
      "name": "LinkedIn",
      "type": "n8n-nodes-base.linkedIn",
      "position": [
        1060,
        620
      ],
      "parameters": {
        "postAs": "organization",
        "additionalFields": {},
        "shareMediaCategory": "IMAGE"
      },
      "credentials": {
        "linkedInOAuth2Api": {
          "id": "YOUR_LINKEDIN_CREDENTIAL_ID",
          "name": "LinkedIn OAuth2 API"
        }
      },
      "typeVersion": 1
    }
  ],
  "active": false,
  "settings": {
    "executionOrder": "v1"
  },
  "connections": {
    "Merge": {
      "main": [
        [
          {
            "node": "LinkedIn",
            "type": "main",
            "index": 0
          }
        ]
      ]
    },
    "OpenAI": {
      "main": [
        [
          {
            "node": "Merge",
            "type": "main",
            "index": 0
          }
        ]
      ]
    },
    "Content creator": {
      "main": [
        [
          {
            "node": "OpenAI",
            "type": "main",
            "index": 0
          },
          {
            "node": "Hashtag generator /SEO",
            "type": "main",
            "index": 0
          }
        ]
      ]
    },
    "Schedule Trigger": {
      "main": [
        [
          {
            "node": "Content topic generator2",
            "type": "main",
            "index": 0
          }
        ]
      ]
    },
    "OpenAI Chat Model": {
      "ai_languageModel": [
        [
          {
            "node": "Content topic generator2",
            "type": "ai_languageModel",
            "index": 0
          }
        ]
      ]
    },
    "OpenAI Chat Model1": {
      "ai_languageModel": [
        [
          {
            "node": "Content creator",
            "type": "ai_languageModel",
            "index": 0
          }
        ]
      ]
    },
    "OpenAI Chat Model2": {
      "ai_languageModel": [
        [
          {
            "node": "Hashtag generator /SEO",
            "type": "ai_languageModel",
            "index": 0
          }
        ]
      ]
    },
    "Hashtag generator /SEO": {
      "main": [
        [
          {
            "node": "Merge",
            "type": "main",
            "index": 1
          }
        ]
      ]
    },
    "Content topic generator2": {
      "main": [
        [
          {
            "node": "Content creator",
            "type": "main",
            "index": 0
          }
        ]
      ]
    },
    "Structured Output Parser": {
      "ai_outputParser": [
        [
          {
            "node": "Content topic generator2",
            "type": "ai_outputParser",
            "index": 0
          }
        ]
      ]
    },
    "Structured Output Parser1": {
      "ai_outputParser": [
        [
          {
            "node": "Content creator",
            "type": "ai_outputParser",
            "index": 0
          }
        ]
      ]
    },
    "Structured Output Parser2": {
      "ai_outputParser": [
        [
          {
            "node": "Hashtag generator /SEO",
            "type": "ai_outputParser",
            "index": 0
          }
        ]
      ]
    }
  },
  "id": 4968
}
```
</details>