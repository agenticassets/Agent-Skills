# Social Media & Video

TikTok, Instagram, YouTube automation and AI video generation

Total: 1 templates

## Template List

- [Generate AI Viral Videos with Seedance and Upload to TikTok, YouTube & Instagram](./5338-generate-ai-viral-videos-with-seedance-and-upload-to-tiktok-.md) - 214,907 views
